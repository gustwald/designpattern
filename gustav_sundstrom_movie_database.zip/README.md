# designpattern 
## https://github.com/gustwald/designpattern